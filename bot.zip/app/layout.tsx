/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║                                                                  ║
 * ║   ███╗   ██╗███████╗██╗  ██╗████████╗██████╗ ███████╗██╗   ██╗   ║
 * ║   ████╗  ██║██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔════╝██║   ██║   ║
 * ║   ██╔██╗ ██║█████╗   ╚███╔╝    ██║   ██║  ██║█████╗  ██║   ██║   ║
 * ║                                                                  ║
 * ║            © 2026 NextDev — All Rights Reserved                  ║
 * ║                                                                  ║
 * ║   discord    ──  https://discord.gg/mxkke6dP8n                   ║
 * ║   developer  ──  ShadowPlayzYT                                   ║
 * ║                                                                  ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";

import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/components/auth-provider";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

const brandName = process.env.NEXT_PUBLIC_BRAND_NAME || "NextDev";

export const metadata: Metadata = {
  title: `${brandName} - Ultimate Discord Bot`,
  description: "Advanced Discord community management and security.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${outfit.variable}`}>
      <body className="font-sans antialiased text-slate-200">
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
