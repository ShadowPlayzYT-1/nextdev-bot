/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║                                                                  ║
 * ║   ███╗   ██╗███████╗██╗  ██╗████████╗██████╗ ███████╗██╗   ██╗   ║
 * ║   ████╗  ██║██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔════╝██║   ██║   ║
 * ║   ██╔██╗ ██║█████╗   ╚███╔╝    ██║   ██║  ██║█████╗  ██║   ██║   ║
 * ║                                                                  ║
 * ║            © 2026 NextDev — All Rights Reserved                  ║
 * ║                                                                  ║
 * ║   discord    ──  https://discord.gg/mxkke6dP8n                   ║
 * ║   developer  ──  ShadowPlayzYT                                   ║
 * ║                                                                  ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import * as React from "react"
import { cn } from "@/lib/utils"

const Label = React.forwardRef<
  HTMLLabelElement,
  React.LabelHTMLAttributes<HTMLLabelElement>
>(({ className, ...props }, ref) => (
  <label
    ref={ref}
    className={cn(
      "text-sm font-bold leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-slate-300",
      className
    )}
    {...props}
  />
))
Label.displayName = "Label"

export { Label }
